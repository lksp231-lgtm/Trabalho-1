// script.js - interatividade simples
document.addEventListener('DOMContentLoaded', function(){
  var menu = document.getElementById('menuToggle');
  if(menu){
    menu.addEventListener('click', function(){
      document.body.classList.toggle('menu-open');
      menu.classList.toggle('active');
    });
  }

  // Simple form validation feedback
  var form = document.getElementById('contactForm');
  if(form){
    form.addEventListener('submit', function(e){
      if(!form.checkValidity()){
        e.preventDefault();
        alert('Por favor, preencha os campos obrigatórios corretamente.');
      } else {
        e.preventDefault();
        alert('Formulário enviado (simulação). Obrigado!');
        form.reset();
      }
    });
  }
});
